#include <stdio.h>
#include "xil_types.h"
#include "mypixfull.h"
#include "xparameters.h"
#include "stdio.h"
#include "xil_io.h"
#include "xil_cache.h"
// Another way to do this is by using the devcfg_polled_example.c: you load the .bin file using XMD and then use this devcfg_polled_example.c file

// libraries to read/write SD
#include "xsdps.h" // SD device driver
#include "ff.h" // FAT system module.

#include "xtra_func.h"
// libraries for DevC (including PCAP and DMA)
#include "xdevcfg.h"

// Requirements:
// - It requires the inclusion of "xilffs_v3_3" in the BSP manually!
// - *NOTE: in ffconf.h we need to do: #define	_USE_STRFUNC 1 (it was 0 originally)
// - In 'Generate Linker Script', change the heap/stack size to allow for input, intermedidate data.
//   Also, place the code, and heap/stack in the largest memory (DDR).

FATFS FatFs; // work area (file system object) for logical drive

#define SLCR_LOCK	0xF8000004 /**< SLCR Write Protection Lock */
#define SLCR_UNLOCK	0xF8000008 /**< SLCR Write Protection Unlock */
#define SLCR_LVL_SHFTR_EN 0xF8000900 /**< SLCR Level Shifters Enable */
#define SLCR_PCAP_CLK_CTRL XPAR_PS7_SLCR_0_S_AXI_BASEADDR + 0x168 /**< SLCR
					* PCAP clock control register address
					*/

#define SLCR_PCAP_CLK_CTRL_EN_MASK 0x1
#define SLCR_LOCK_VAL	0x767B
#define SLCR_UNLOCK_VAL	0xDF0D

//int load_sd_to_memory (char *filename, u8* dataPtr, u32 *DataLength);
int load_bit_to_pcap (XDcfg *DevcfgInstPtr , u8 *dataPtr, UINT BitstreamLength, u8 flags);
void pixfull_test (u32 baseaddr);

// TODO: - group reading SD files, writing on PCAP on functions!, document!

int main()
{
    u32 Status;
	u8 *in_dat, *in_datb;
	u32 BitstreamSize, BitstreamSizeb;
    u32 pixfull_baseaddr = XPAR_MYPIXFULL_0_S00_AXI_BASEADDR; //  baseaddr = 0x7AA00000; // fixed in Vivado 2016.2!
    FRESULT mystat;

    xil_printf ("\nSD + DPR Test:\n************************\n");

   	pixfull_test(pixfull_baseaddr); // Testing write/read on AXI-4 Full Peripheral - Pixel Processor: Initial Configuration

    in_dat = (u8 *) calloc (200000,sizeof(u8));
    if (in_dat == NULL) {xil_printf("(main): not enough memory\r\n"); return -1;}

    in_datb = (u8 *) calloc (200000,sizeof(u8));
    if (in_datb == NULL) {xil_printf("(main): not enough memory\r\n"); return -1;}

    // Stream partial bitstream to PCAP: Transfer Bitfile using DEVCFG/PCAP
    	XDcfg Instdevcfg;

    // Mounting SD Drive
	   mystat = f_mount(&FatFs, "0:/", 1); // register work area to the default drive ("0:/")
	   if (mystat != FR_OK) { xil_printf("f_mount: Error!\n"); return XST_FAILURE; };

    // Read partial bitstream files from SD and place them in memory
    //Status = load_sd_to_memory ("pix_1p.bin", in_dat, &BitstreamSize);
    Status = load_sd_to_memory ("pix_1p.bin", in_dat, &BitstreamSize, 1);

    if (Status != XST_SUCCESS) { xil_printf ("(main) Error loading file from SD to memory!\n"); return -1; }

    //Status = load_sd_to_memory ("pix_2p.bin", in_datb, &BitstreamSizeb);
    Status = load_sd_to_memory ("pix_2p.bin", in_datb, &BitstreamSizeb, 1);
    if (Status != XST_SUCCESS) { xil_printf ("(main) Error loading file from SD to memory!\n"); return -1; }

	Xil_DCacheFlush(); // either disable or flush! (VERY IMPORTANT)

	// Performing DPR: (1st).. the best way to test it is to load the SECOND full configuration first!
	Status = load_bit_to_pcap (&Instdevcfg , in_dat, BitstreamSize, 0x00); // Assumption: Bitstreamsize is multiple of 4
    if (Status != XST_SUCCESS) { xil_printf("(main) Error performing DPR!"); return -1; }

    pixfull_test(pixfull_baseaddr); // Testing write/read on AXI-4 Full Peripheral - Pixel Processor: First Configuration

	// Performing DPR: (2nd)
	Status = load_bit_to_pcap (&Instdevcfg , in_datb, BitstreamSizeb, 0x00); // Assumption: Bitstreamsize is multiple of 4
    if (Status != XST_SUCCESS) { xil_printf("(main) Error performing DPR!"); return -1; }

    pixfull_test(pixfull_baseaddr); // Testing write/read on AXI-4 Full Peripheral - Pixel Processor: Second Configuration

    //Xil_DCacheEnable(); Xil_ICacheEnable();   // Enabling caches
    //Xil_DCacheDisable(); Xil_ICacheDisable();
    return 0;
}

int load_bit_to_pcap (XDcfg *DevcfgInstPtr, u8 *dataPtr, UINT BitstreamLength, u8 flags)
// We load partial bitstreams (.bin format) to PCAP:
//    Usually, we would use a function to read the header of a .bit file and extract size. Now (7 Series), apparently we can't. We have to use .bin files
//    we could try to parse the header (manually, we discovered in one example the header to be 125 bytes) and get the bitstream size, but Xilinx does not provide
//    any help on this
// this only does PArtial REconfiguration. For full reconf,. details, see devcfg_polled_example.c
// ASSUMPTION: Bitstreamlength is multiple of 4
// BitstreamLength: Size of bitstream (bytes): It has to be a multiple of 4
// flags: various options:
//  flags = 0x?E: We print registers at the end
//  flags = 0xA?: Order of bytes is swapped (this is when the .bin was generated by write_bitstream)

// This can be very useful. For example: flags=0xAE: swap byte order and print registers at the end.
{
	u32 IntrStsReg = 0;
    XDcfg_Config *ConfigPtr;
    int Status;
    int i;
    u8 ta, tb, tc, td;

    // In a .bit file, the header is included. If the header is 125 bytes, we can do this:
      // in_dat = in_dat + 0x0000007D; // used to skip the header in a .bit file.
      // BitstreamLength = BitstreamLenght-125;
    // Also note that for a .bit file, we need to swap the byte order.

    if ( (flags & 0xF0) == 0xA0) {
       // Little-endian: the .bin generated by write_bitstream. We need to swap the byte order in a 32-bit word
       xil_printf ("(load_bit_to_pcap): Swapping bytes in a 32-bit word\n");

       for (i=0; i< BitstreamLength/4; i++)
       {
    	   ta = dataPtr[4*i]; tb = dataPtr[4*i+1]; tc = dataPtr[4*i+2]; td = dataPtr[4*i+3];
    	   dataPtr[4*i] = td; dataPtr[4*i+1] = tc; dataPtr[4*i+2] = tb; dataPtr[4*i+3] = ta;
       }
    }

    // Use XMD%mrd to see data in memory (32-bit words, byte at 0 is the LSByte).
    // To see data byte-wise, use:
    // for ( i = 0; i < BitstreamLength; i++ ) xil_printf("Received data: %d: 0x%02X\n", i,*(in_dat + i) );

	//XDcfg Instpcap;
	u16 DeviceId = XPAR_PS7_DEV_CFG_0_DEVICE_ID;

	// Performing DPR:
	ConfigPtr = XDcfg_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {xil_printf ("(load_bit_to_pcap) XDcfg_LookupConfig failed\n"); return XST_FAILURE;}

	// Using Physical Address to initialize Devcfg
	Status = XDcfg_CfgInitialize(DevcfgInstPtr, ConfigPtr, ConfigPtr->BaseAddr);
	if (Status != XST_SUCCESS) { xil_printf ("(load_bit_to_pcap) XDcfg_CfgInitiliaze failed!\n"); return XST_FAILURE; }
	XDcfg_SetLockRegister(DevcfgInstPtr, XDCFG_UNLOCK_DATA); //0x757BDF0D);

	// Check 1st time configuration or not. If it is not, this is likely a Partial Reconfiguration.
	//  But even if it is the 1st, we can also do Partial Reconfiguration
	IntrStsReg = XDcfg_IntrGetStatus(DevcfgInstPtr); xil_printf ("IntrStsReg: %08X: \n",IntrStsReg);
	if (IntrStsReg & XDCFG_IXR_DMA_DONE_MASK) xil_printf("PartialCfg = 1 (i.e., not 1st configuration)!\n");

	// enable PCAP clock:
	Status = Xil_In32(SLCR_PCAP_CLK_CTRL);
	if (!(Status & SLCR_PCAP_CLK_CTRL_EN_MASK)) {
			Xil_Out32(SLCR_UNLOCK, SLCR_UNLOCK_VAL);
			Xil_Out32(SLCR_PCAP_CLK_CTRL, (Status | SLCR_PCAP_CLK_CTRL_EN_MASK));
			Xil_Out32(SLCR_UNLOCK, SLCR_LOCK_VAL);
	}

	// Enable PCAP interface for Partial Reconfiguration: Configure muxes so that the PCAP Path is enabled to write on PL Conf. Module
	XDcfg_SetControlRegister(DevcfgInstPtr, XDCFG_CTRL_PCAP_MODE_MASK); // Setting control register for PCAP mode --> this is also done by XDcfg_EnablePCAP(DevcfgInstPtr)
	XDcfg_SetControlRegister(DevcfgInstPtr, XDCFG_CTRL_PCAP_PR_MASK);  // Setting PR mode
     // We should probably go back to the orig. state when done)

	// Clear Interrupt Status Bits: DMA and PCAP Done Interrupts
	XDcfg_IntrClear(DevcfgInstPtr, (XDCFG_IXR_PCFG_DONE_MASK | XDCFG_IXR_DMA_DONE_MASK | XDCFG_IXR_D_P_DONE_MASK));
    xil_printf ("Interrupt Status bits cleared!\n");

    // Check if DMA command queue is full:
	Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_STATUS_OFFSET); // sometimes they use Inspcap->Config.BaseAddr
	if ((Status & XDCFG_STATUS_DMA_CMD_Q_F_MASK) == XDCFG_STATUS_DMA_CMD_Q_F_MASK) {
	    xil_printf("DMA command queue is full.\n\r"); return XST_FAILURE; }

	xil_printf ("DPR: Transfer to start: Source Address: %08X...\n", dataPtr);

	// Download bitstream to PL in nonsecure more:
	Status = XDcfg_Transfer(DevcfgInstPtr, dataPtr, BitstreamLength/4, (u8 *) XDCFG_DMA_INVALID_ADDRESS, 0, XDCFG_NON_SECURE_PCAP_WRITE);
	if (Status != XST_SUCCESS) { xil_printf ("XDcfg_Transfer: failure: %d\n",Status); return XST_FAILURE; }

	xil_printf ("DPR: Transfer completed!\n");

	IntrStsReg = XDcfg_IntrGetStatus(DevcfgInstPtr);
	// Poll DMA Done Interrupt
	while ((IntrStsReg & XDCFG_IXR_DMA_DONE_MASK) != XDCFG_IXR_DMA_DONE_MASK) IntrStsReg = XDcfg_IntrGetStatus(DevcfgInstPtr);

	// Poll PCAP Done Interrupt
	while ((IntrStsReg & XDCFG_IXR_D_P_DONE_MASK) != XDCFG_IXR_D_P_DONE_MASK) IntrStsReg = XDcfg_IntrGetStatus(DevcfgInstPtr);

	if ( (flags & 0x0F) == 0x0E ) {
		xil_printf ("\nINS_STS: Interrupt Status Register: %08X: \n",IntrStsReg);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_STATUS_OFFSET);
		xil_printf ("STATUS Register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_CTRL_OFFSET);
		xil_printf ("CONTROL register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_CFG_OFFSET);
		xil_printf ("CONFIGURATION Register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_DMA_SRC_ADDR_OFFSET);
		xil_printf ("SRC ADDRESS register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_DMA_DEST_ADDR_OFFSET);
		xil_printf ("DEST ADDRESS register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_DMA_SRC_LEN_OFFSET);
		xil_printf ("SRC LENGTH register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_DMA_DEST_LEN_OFFSET);
		xil_printf ("DEST LENGHT register: %08X: \n",Status);
	}
	return XST_SUCCESS;
	}

void pixfull_test (u32 baseaddr)
{
    u32 Mem32Value;
    int i;

	xil_printf("(pixfull_test): AXI-4 Full Pixel Processor Test, Base Address: %08X\n",baseaddr);

	// Write data to the FIFOs: Since we write on FIFOs, we only use the same address
	//   (we can use any address in the memory space of the peripheral)
	MYPIXFULL_mWriteMemory(baseaddr, (0xDEADBEEF));
	MYPIXFULL_mWriteMemory(baseaddr, (0xBEBEDEAD));
	MYPIXFULL_mWriteMemory(baseaddr, (0xFADEBEAD));
	MYPIXFULL_mWriteMemory(baseaddr, (0xCAFEBEDF));

	// Reading data:
	for ( i = 0; i < 4; i++ ) {
	     Mem32Value = MYPIXFULL_mReadMemory(baseaddr+4*i); // I do not thing the address matters here
	     xil_printf("Received Data: 0x%08x\n", Mem32Value);
	}
}

