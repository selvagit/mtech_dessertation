#include <stdio.h>
#include "mydctfull.h"
#include "xparameters.h"
#include "stdio.h"
#include "xil_io.h"

void dctfull_test (u32 baseaddr, u32 tsize);

int main()
{
	u32 baseaddr, dctsize;
    baseaddr = XPAR_MYDCTFULL_0_S00_AXI_BASEADDR; // from xparameters.h.
    // Sometimes, due to a bug, we do not have the correct XPAR_MYDCTFULL_0_S00_AXI_BASEADDR
    // You have to look into Vivado for the peripheral address: baseaddr = 0x7AA00000;

	// Enabling caches
	//Xil_DCacheEnable(); Xil_ICacheEnable();

	// This is just to reset the RP after each partial reconfiguration (we will do this automatically later after each DPR via software)
    xil_printf ("Issuing PR_reset..\n"); // Address: 1011 00 (11*4)
	MYDCTFULL_mWriteMemory(baseaddr + 11*4, (0xAA995577));

    xil_printf("Base memory address (DCT FULL): 0x%08x\n", baseaddr);
    dctsize = 4; // 4x4

    // This is a test that checks the first 2 blocks. Transform Size: 4x4
    dctfull_test(baseaddr, dctsize); // Testing write/read on AXI-4 Full Peripheral - Pixel Processor: Initial Configuration

    // Disabling caches
	//Xil_DCacheDisable(); Xil_ICacheDisable();

    return 0;
}

void dctfull_test (u32 baseaddr, u32 tsize)
{
    u32 Mem32Value;
    int i;

    xil_printf("DCT 2D AXI4-Full Peripheral - Test.\n");
    xil_printf ("DCT TRANSFORM SIZE: %d\n", tsize);

    if (tsize == 4)
    {
    	// Input data: 4x4 Block (bit-width: 8): Data is entered column-wise. Each column is a 32-bit word
    	// Address: baseaddr + 0. AXI4-Full Peripheral was built so that writes/read occur in any of the 64-byte memory range.
    	// Output Data: 4x4 Block (bit-width: 16): Data is received row-wise. Each row is a 64-bit word
		xil_printf ("First block\n\r");
		MYDCTFULL_mWriteMemory(baseaddr, (0xDEADBEEF));
		MYDCTFULL_mWriteMemory(baseaddr, (0xBEBEDEAD));
		MYDCTFULL_mWriteMemory(baseaddr, (0xFADEBEAD));
		MYDCTFULL_mWriteMemory(baseaddr, (0xCAFEBEDF));
		xil_printf(" Data written !!\n\r");

		for ( i = 0; i < 8; i++ ) {
		  Mem32Value = MYDCTFULL_mReadMemory(baseaddr); // we get the same results here (as expected, by reading anything on the 64-bytes we read the same)
		  xil_printf("Received data is 0x%08x\n", Mem32Value); }

		xil_printf ("Second block\n\r");
		MYDCTFULL_mWriteMemory(baseaddr, (0xCFC7C9C7)); // same thing, the index does not make a difference, it seems
		MYDCTFULL_mWriteMemory(baseaddr, (0xCAC4C6C3));
		MYDCTFULL_mWriteMemory(baseaddr, (0xC6C3C7C3));
		MYDCTFULL_mWriteMemory(baseaddr, (0xBEBDC2BD));

		xil_printf(" Data written !!\n\r");
		for ( i = 0; i < 8; i++ ) {
		  Mem32Value = MYDCTFULL_mReadMemory(baseaddr); // we get the same results here (as expected, by reading anything on the 64-bytes we read the same)
		  xil_printf("Received data is 0x%08x\n", Mem32Value); }
    }
    else if (tsize == 8)
    {
    	// Input data: 8x8 Block (bit-width: 8): Data is entered column-wise. Each column is a 64-bit word
    	// Address: baseaddr + 0. AXI4-Full Peripheral was built so that writes/read occur in any of the 64-byte memory range.
    	// Output Data: 8x8 Block (bit-width: 16): Data is received row-wise. Each row is a 128-bit word
        xil_printf ("First Block:\n"); // data is entered column-wise
        MYDCTFULL_mWriteMemory(baseaddr, (0x7d807e79)); MYDCTFULL_mWriteMemory(baseaddr, (0x7c7e7d77));
        MYDCTFULL_mWriteMemory(baseaddr, (0x7c7a7a82)); MYDCTFULL_mWriteMemory(baseaddr, (0x7d787c81));
        MYDCTFULL_mWriteMemory(baseaddr, (0x7f7c7b81)); MYDCTFULL_mWriteMemory(baseaddr, (0x7c797d7f));
        MYDCTFULL_mWriteMemory(baseaddr, (0x827e7b7f)); MYDCTFULL_mWriteMemory(baseaddr, (0x7b7a7d7c));

        MYDCTFULL_mWriteMemory(baseaddr, (0x807e7b7e)); MYDCTFULL_mWriteMemory(baseaddr, (0x7a7b7d7a));
        MYDCTFULL_mWriteMemory(baseaddr, (0x7c7c7b7e)); MYDCTFULL_mWriteMemory(baseaddr, (0x7a7b7c79));
        MYDCTFULL_mWriteMemory(baseaddr, (0x7b7d7c7e)); MYDCTFULL_mWriteMemory(baseaddr, (0x7c797b7b));
        MYDCTFULL_mWriteMemory(baseaddr, (0x7f807d7d)); MYDCTFULL_mWriteMemory(baseaddr, (0x7d78797d));

    	xil_printf("Data written!!\n\r"); // data is read column-wise as well (remember that we read the row of Y', i.e. col of Y)
    	for ( i = 0; i < 32; i++ ) {
    	  Mem32Value = MYDCTFULL_mReadMemory(baseaddr); // we get the same results here (as expected, by reading anything on the 64-bytes we read the same)
    	  xil_printf("Received data: 0x%08x\n", Mem32Value); }
    }
    else
    	xil_printf ("Invalid Transform size (only 4 and 8 are supported!\n");
}
