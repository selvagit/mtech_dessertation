#include <stdio.h>
#include "xil_types.h"
#include "mydfxaddsubintr.h"
#include "xparameters.h"
#include "stdio.h"
#include "xil_io.h"
#include "xil_cache.h"

// libraries to read/write SD
#include "xsdps.h" // SD device driver
#include "ff.h" // FAT system module.

#include "xtra_func.h"
// libraries for DevC (including PCAP and DMA)
#include "xdevcfg.h"

#include "xscugic.h"
/* Requirements:
   - It requires the inclusion of "xilffs_v3_3" in the BSP manually!
   - *NOTE: in ffconf.h we need to do: #define	_USE_STRFUNC 1 (it was 0 originally)
   - In 'Generate Linker Script', change the heap/stack size to allow for input, intermediate data.
     Also, place the code, and heap/stack in the largest memory (DDR).
     This project has been tested to work with: Heap: 3.89 MB  Stack: 51.75 KB. Bitstream size: 1194704 bytes
*/
FATFS FatFs; // work area (file system object) for logical drive

#define SLCR_LOCK	0xF8000004 /**< SLCR Write Protection Lock */
#define SLCR_UNLOCK	0xF8000008 /**< SLCR Write Protection Unlock */
#define SLCR_LVL_SHFTR_EN 0xF8000900 /**< SLCR Level Shifters Enable */
#define SLCR_PCAP_CLK_CTRL XPAR_PS7_SLCR_0_S_AXI_BASEADDR + 0x168 /**< SLCR
					* PCAP clock control register address
					*/

#define SLCR_PCAP_CLK_CTRL_EN_MASK 0x1
#define SLCR_LOCK_VAL	0x767B
#define SLCR_UNLOCK_VAL	0xDF0D

#define INTC_DEVICE_ID			XPAR_SCUGIC_SINGLE_DEVICE_ID

int load_bit_to_pcap (XDcfg *DevcfgInstPtr , u8 *dataPtr, UINT BitstreamLength, u8 flags);
void dfx16add_test(u32 baseaddr, u32 format);

int SetupInterruptSystem(XScuGic *GicPtr);
void DeviceDriverHandler(void *CallbackRef);

volatile static int InterruptProcessed = FALSE;

XScuGic GicInstance;

/*
  IMPORTANT: [n p0 p1]. When doing addition, for the same 'n':
                       - We get the same result (regardless of p0 and p1) when we do num0+num0 or num1+num1.
                       - We get the same result when do num0+num1 if p0-p1 is the same for different DFX formats
                       - We get different results if we do num0 + num1 if p0-p1 are different for different DFX formats
             This is why we are choosing [16 8 4], [16 7 2].
*/

// DPR: we do not DPR inside the ISR. Instead, once we process a chunk of data and if overflow occurred, we do DPR:
/* Procedure
 * - Start with [16 8 4]. Test data. An overflow will occur on C000+F1C3
 * - Once we finish processing the data, if the overflow occurred (which it will), we reconfigure to [16 7 2].
 * -  We test the DFX ADD [16 7 2] with data meant to be processed in [16 8 4]. Because of this, we expect different results.
 *     An overflow will be detected, but we won't do DPR because of this.
 *     This will demonstrate that we effectively did DPR to [16 7 2].
 * -  We test the DFX ADD [16 7 2] with data converted to [16 7 2] (from the set in [16 8 4]). This is the real test. No overflow occurs here
 * - We reconfigure (unconditionally) to [16 8 4] and test the proper data in [16 8 4]. An Overflow will be detected, but no DPR will be executed.
 */

int main()
{
    u32 Status;
	u8 *in_bit8_4, *in_bit7_2;
	u32 BitstreamSizea, BitstreamSizeb;
    u32 baseaddr = XPAR_MYDFXADDSUBINTR_0_S00_AXI_BASEADDR; //  baseaddr = 0x7AA00000; // fixed in Vivado 2016.2!
    FRESULT mystat;

	// Setup the Interrupt System: GIC (General Interrupt Controller)
	// ***************************************************************
	   Status = SetupInterruptSystem(&GicInstance);
	   if (Status != XST_SUCCESS) { xil_printf ("Setup Interrupt System failed!\n"); return XST_FAILURE; }

    xil_printf ("\nInterrupt + DPR Test:\n************************\n");

    in_bit8_4 = (u8 *) calloc (80000,sizeof(u8));
    if (in_bit8_4 == NULL) {xil_printf("(main): not enough memory\r\n"); return -1;}

    in_bit7_2 = (u8 *) calloc (80000,sizeof(u8));
    if (in_bit7_2 == NULL) {xil_printf("(main): not enough memory\r\n"); return -1;}

    // Stream partial bitstream to PCAP: Transfer Bitfile using DEVCFG/PCAP
    	XDcfg Instdevcfg;

    // Mounting SD Drive
	   mystat = f_mount(&FatFs, "0:/", 1); // register work area to the default drive ("0:/")
	   if (mystat != FR_OK) { xil_printf("f_mount: Error!\n"); return XST_FAILURE; };

    // Read partial bitstream files from SD and place them in memory
    Status = load_sd_to_memory ("dfx8_4.bin", in_bit8_4, &BitstreamSizea, 1);
    if (Status != XST_SUCCESS) { xil_printf ("(main) Error loading file from SD to memory!\n"); return -1; }

    Status = load_sd_to_memory ("dfx7_2.bin", in_bit7_2, &BitstreamSizeb, 1);
    if (Status != XST_SUCCESS) { xil_printf ("(main) Error loading file from SD to memory!\n"); return -1; }

    // **** TESTING ///
    // Initial Configuration: [16 8 4]. Testing data: 9 additions
    dfx16add_test(baseaddr, 1);

   // Here we check if there was overflow to see if we need to do DPR:
	   if (InterruptProcessed==TRUE) // return value from the ISR
		   {  InterruptProcessed = FALSE;
		      xil_printf ("Doing DPR.. Convert to [16 7 2].\n");

		      Xil_DCacheFlush(); // either disable or flush! (VERY IMPORTANT)
		      // Performing DPR:  Load [16 7 2]
		  	  Status = load_bit_to_pcap (&Instdevcfg , in_bit7_2, BitstreamSizeb, 0x00); // Assumption: Bitstreamsize is multiple of 4
		      if (Status != XST_SUCCESS) { xil_printf("(main) Error performing DPR!"); return -1; }

		      // Issuing PR_reset: To reset the RP and FIFOs after each partial reconfiguration
		      xil_printf ("Asserting PR_reset. \n"); // Address: 1011 00 (11*4)
		      MYDFXADDSUBINTR_mWriteMemory(baseaddr + 11*4, (0xAA995577));
		      xil_printf ("Ready..\n"); // IMPORTANT: need a small delay after the previous instruction (which will stop operations for 16 cycles)
		      // seems that we need to delay here a little bit before we restart.... if we do not include this xil_printf, the 1st inst. will be ignored
              // you either place the delay here.. or before the next write/read is executed
		    }

	    // **** TESTING ///
	      // We use data for [16 8 4]. But it will be processed as [16 7 2], thereby giving different results.
	      // This is just to show that we effectively modified the DFX format.
	    dfx16add_test(baseaddr, 1); // We should see overflow here in C000+F1C3

	    // **** TESTING ///
	    // Second Configuration: [16 7 2]. Testing data: 9 additions
	      // Here, we use input data in format [16 7 2]. We converted the data in [16 8 4] to format [16 7 2]. This is the real test
	    dfx16add_test(baseaddr, 2); // No overflow should occur here.

	// We reconfigure back to [16 8 4]
	// Performing DPR: Load [16 8 4]
	   xil_printf ("Doing DPR.. Convert to [16 8 4].\n");
       Xil_DCacheFlush(); // either disable or flush! (VERY IMPORTANT)
       Status = load_bit_to_pcap (&Instdevcfg , in_bit8_4, BitstreamSizea, 0x00); // Assumption: Bitstreamsize is multiple of 4
       if (Status != XST_SUCCESS) { xil_printf("(main) Error performing DPR!"); return -1; }

	// We must reset the RP and FIFOs after each partial reconfiguration
       xil_printf ("Asserting PR_reset. \n"); // Address: 1011 00 (11*4)
	   MYDFXADDSUBINTR_mWriteMemory(baseaddr + 11*4, (0xAA995577));
       xil_printf ("Ready...\n"); // IMPORTANT: need a small delay after the previous instruction (which will stop operations for 16 cycles)
	   // seems that we need to delay here a little bit before we restart.... if we do not include this xil_printf, the 1st inst. will be ignored

	    // **** TESTING ///
	    // First Configuration: [16 8 4]. Testing data: 9 additions
	    dfx16add_test(baseaddr, 1); // We should see overflow here in C000+F1C3

    free(in_bit8_4); free(in_bit7_2);
    return 0;
}

// ******************* FUNCTION DEFINITIONS ***********************************
void dfx16add_test(u32 baseaddr, u32 format)
{
	// Format: 1: [16 8 4]
	//         2: [16 7 2]
    int i;
	  xil_printf ("Testing 9 DFX 16-bit additions."); // Testing data: 9 32-bit words.
	  if (format == 1)
	  {
		  xil_printf ("This is data in format [16 8 4]:\n");
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0x75AFFBC4);
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0xCAFEBEBE);
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0x7FA17E52);
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0x3FF13F04);
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0xC421054A);
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0xFA2A0A09);
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0xC000F1C3); // this causes overflow!
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0xD001F170);
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0xFAF8300A);
	  }
	  else
	  {
		  xil_printf ("This is data in format [16 7 2]:\n");
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0x78D75E20);
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0xF2BF8FAF);
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0x7FD07F29);
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0x1FF81F82);
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0xF10802A5);
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0x51500504);
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0xF000FC70); // this causes overflow!
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0xF400FC5C);
		  MYDFXADDSUBINTR_mWriteMemory(baseaddr, 0x57C01805);

	  }
	  for (i=0; i < 9; i++)
	   	xil_printf ("\tReceived data: 0x%08x\n", MYDFXADDSUBINTR_mReadMemory(baseaddr));
}

int load_bit_to_pcap (XDcfg *DevcfgInstPtr, u8 *dataPtr, UINT BitstreamLength, u8 flags)
// We load partial bitstreams (.bin format) to PCAP:
//    Usually, we would use a function to read the header of a .bit file and extract size. Now (7 Series), apparently we can't. We have to use .bin files
//    we could try to parse the header (manually, we discovered in one example the header to be 125 bytes) and get the bitstream size, but Xilinx does not provide
//    any help on this
// this only does PArtial REconfiguration. For full reconf,. details, see devcfg_polled_example.c
// ASSUMPTION: Bitstreamlength is multiple of 4
// BitstreamLength: Size of bitstream (bytes): It has to be a multiple of 4
// flags: various options:
//  flags = 0x?E: We print registers at the end
//  flags = 0xA?: Order of bytes is swapped (this is when the .bin was generated by write_bitstream)

// This can be very useful. For example: flags=0xAE: swap byte order and print registers at the end.
{
	u32 IntrStsReg = 0;
    XDcfg_Config *ConfigPtr;
    int Status;
    int i;
    u8 ta, tb, tc, td;

    // In a .bit file, the header is included. If the header is 125 bytes, we can do this:
      // in_dat = in_dat + 0x0000007D; // used to skip the header in a .bit file.
      // BitstreamLength = BitstreamLenght-125;
    // Also note that for a .bit file, we need to swap the byte order.

    if ( (flags & 0xF0) == 0xA0) {
       // Little-endian: the .bin generated by write_bitstream. We need to swap the byte order in a 32-bit word
       xil_printf ("(load_bit_to_pcap): Swapping bytes in a 32-bit word\n");

       for (i=0; i< BitstreamLength/4; i++)
       {
    	   ta = dataPtr[4*i]; tb = dataPtr[4*i+1]; tc = dataPtr[4*i+2]; td = dataPtr[4*i+3];
    	   dataPtr[4*i] = td; dataPtr[4*i+1] = tc; dataPtr[4*i+2] = tb; dataPtr[4*i+3] = ta;
       }
    }

    // Use XMD%mrd to see data in memory (32-bit words, byte at 0 is the LSByte).
    // To see data byte-wise, use:
    // for ( i = 0; i < BitstreamLength; i++ ) xil_printf("Received data: %d: 0x%02X\n", i,*(in_dat + i) );

	//XDcfg Instpcap;
	u16 DeviceId = XPAR_PS7_DEV_CFG_0_DEVICE_ID;

	// Performing DPR:
	ConfigPtr = XDcfg_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {xil_printf ("(load_bit_to_pcap) XDcfg_LookupConfig failed\n"); return XST_FAILURE;}

	// Using Physical Address to initialize Devcfg
	Status = XDcfg_CfgInitialize(DevcfgInstPtr, ConfigPtr, ConfigPtr->BaseAddr);
	if (Status != XST_SUCCESS) { xil_printf ("(load_bit_to_pcap) XDcfg_CfgInitiliaze failed!\n"); return XST_FAILURE; }
	XDcfg_SetLockRegister(DevcfgInstPtr, XDCFG_UNLOCK_DATA); //0x757BDF0D);

	// Check 1st time configuration or not. If it is not, this is likely a Partial Reconfiguration.
	//  But even if it is the 1st, we can also do Partial Reconfiguration
	IntrStsReg = XDcfg_IntrGetStatus(DevcfgInstPtr); xil_printf ("(load_bit_to_pcap) IntrStsReg: %08X: \n",IntrStsReg);
	if (IntrStsReg & XDCFG_IXR_DMA_DONE_MASK) xil_printf("PartialCfg = 1 (i.e., not 1st configuration)!\n");
	   // First time Configuration: understood as if the entire chip is programmed. we are not doing this here!.

	// enable PCAP clock:
	Status = Xil_In32(SLCR_PCAP_CLK_CTRL);
	if (!(Status & SLCR_PCAP_CLK_CTRL_EN_MASK)) {
			Xil_Out32(SLCR_UNLOCK, SLCR_UNLOCK_VAL);
			Xil_Out32(SLCR_PCAP_CLK_CTRL, (Status | SLCR_PCAP_CLK_CTRL_EN_MASK));
			Xil_Out32(SLCR_UNLOCK, SLCR_LOCK_VAL);
	}

	// Enable PCAP interface for Partial Reconfiguration: Configure muxes so that the PCAP Path is enabled to write on PL Conf. Module
	XDcfg_SetControlRegister(DevcfgInstPtr, XDCFG_CTRL_PCAP_MODE_MASK); // Setting control register for PCAP mode --> this is also done by XDcfg_EnablePCAP(DevcfgInstPtr)
	XDcfg_SetControlRegister(DevcfgInstPtr, XDCFG_CTRL_PCAP_PR_MASK);  // Setting PR mode
     // We should probably go back to the orig. state when done)

	// Clear Interrupt Status Bits: DMA and PCAP Done Interrupts
	XDcfg_IntrClear(DevcfgInstPtr, (XDCFG_IXR_PCFG_DONE_MASK | XDCFG_IXR_DMA_DONE_MASK | XDCFG_IXR_D_P_DONE_MASK));

    xil_printf ("(load_bit_to_pcap) Interrupt Status bits cleared! IntrStsReg: %08X\n", XDcfg_IntrGetStatus(DevcfgInstPtr));

    // Check if DMA command queue is full:
	Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_STATUS_OFFSET); // sometimes they use Inspcap->Config.BaseAddr
	if ((Status & XDCFG_STATUS_DMA_CMD_Q_F_MASK) == XDCFG_STATUS_DMA_CMD_Q_F_MASK) {
	    xil_printf("DMA command queue is full.\n\r"); return XST_FAILURE; }

	xil_printf ("(load_bit_to_pcap) DPR: Transfer to start: Source Address: %08X...\n", dataPtr);

	// Download bitstream to PL in nonsecure more:
	Status = XDcfg_Transfer(DevcfgInstPtr, dataPtr, BitstreamLength/4, (u8 *) XDCFG_DMA_INVALID_ADDRESS, 0, XDCFG_NON_SECURE_PCAP_WRITE);
	if (Status != XST_SUCCESS) { xil_printf ("XDcfg_Transfer: failure: %d\n",Status); return XST_FAILURE; }

	xil_printf ("(load_bit_to_pcap) DPR: Transfer completed!\n");

	IntrStsReg = XDcfg_IntrGetStatus(DevcfgInstPtr);
	// Poll DMA Done Interrupt
	while ((IntrStsReg & XDCFG_IXR_DMA_DONE_MASK) != XDCFG_IXR_DMA_DONE_MASK) IntrStsReg = XDcfg_IntrGetStatus(DevcfgInstPtr);

	// Poll PCAP Done Interrupt
	while ((IntrStsReg & XDCFG_IXR_D_P_DONE_MASK) != XDCFG_IXR_D_P_DONE_MASK) IntrStsReg = XDcfg_IntrGetStatus(DevcfgInstPtr);

	if ( (flags & 0x0F) == 0x0E ) {
		xil_printf ("\nINS_STS: Interrupt Status Register: %08X: \n",IntrStsReg);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_STATUS_OFFSET);
		xil_printf ("STATUS Register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_CTRL_OFFSET);
		xil_printf ("CONTROL register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_CFG_OFFSET);
		xil_printf ("CONFIGURATION Register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_DMA_SRC_ADDR_OFFSET);
		xil_printf ("SRC ADDRESS register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_DMA_DEST_ADDR_OFFSET);
		xil_printf ("DEST ADDRESS register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_DMA_SRC_LEN_OFFSET);
		xil_printf ("SRC LENGTH register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_DMA_DEST_LEN_OFFSET);
		xil_printf ("DEST LENGTH register: %08X: \n",Status);
	}
	return XST_SUCCESS;
	}


/******************************************************************************/
/**
 *
 * This function connects the interrupt handler of the interrupt controller to
 * the processor.  This function is separate to allow it to be customized for
 * each application. Each processor or RTOS may require unique processing to
 * connect the interrupt handler.
 *
 * @param	GicPtr is the GIC instance pointer.
 * @param	DmaPtr is the DMA instance pointer.
 *
 * @return	None.
 *
 * @note	None.
 *
 ****************************************************************************/
int SetupInterruptSystem(XScuGic *GicPtr)
{
	int Status;
	XScuGic_Config *GicConfig;

	Xil_ExceptionInit();

	/*
	 * Initialize the interrupt controller driver so that it is ready to
	 * use.
	 */
	GicConfig = XScuGic_LookupConfig(INTC_DEVICE_ID);
	if (NULL == GicConfig) { return XST_FAILURE; }

	Status = XScuGic_CfgInitialize(GicPtr, GicConfig,
				       GicConfig->CpuBaseAddress);
	if (Status != XST_SUCCESS) { return XST_FAILURE; }

	/*
	 * Perform a self-test to ensure that the hardware was built
	 * correctly
	 */
	Status = XScuGic_SelfTest(GicPtr);
	if (Status != XST_SUCCESS) {return XST_FAILURE;}

	//XScuGic_CPUWriteReg(GicPtr, XSCUGIC_EOI_OFFSET, 0x3D); // ?????
	/*
	 * Connect the interrupt controller interrupt handler to the hardware
	 * interrupt handling logic in the processor.
	 */
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_IRQ_INT,
			     (Xil_ExceptionHandler)XScuGic_InterruptHandler,
			     GicPtr);
	//Xil_ExceptionEnable();

	Status = XScuGic_Connect (GicPtr, XPS_FPGA0_INT_ID, (Xil_ExceptionHandler) DeviceDriverHandler, (void *) GicPtr);
	if (Status != XST_SUCCESS) {xil_printf("\nError connecting IRQ from PL");return XST_FAILURE;}

	/*
	 * Enable the interrupts for the device
	 */

	XScuGic_Enable(GicPtr, XPS_FPGA0_INT_ID);

	Xil_ExceptionEnable();
	return XST_SUCCESS;
}


void DeviceDriverHandler(void *CallbackRef)
{
	/*
	 * Indicate the interrupt has been processed using a shared variable
	 */
	InterruptProcessed = TRUE;

	// we can also configure stuff here so that only rising edge works
	// So, it is here that we must de-assert the interrupt source.
	MYDFXADDSUBINTR_mWriteMemory(XPAR_MYDFXADDSUBINTR_0_S00_AXI_BASEADDR + (13*4), 0x775599AA); // to de-assert interrupt source
	xil_printf("\n(ISR) PL Interrupt occurred!\n");

}
