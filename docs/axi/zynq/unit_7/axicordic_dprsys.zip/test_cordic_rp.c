#include <stdio.h>
#include "xil_types.h"
#include "mycordicfull.h"
#include "xparameters.h"
#include "stdio.h"
#include "xil_io.h"
#include "xil_cache.h"

// libraries to read/write SD
#include "xsdps.h" // SD device driver
#include "ff.h" // FAT system module.

#include "xtra_func.h"
// libraries for DevC (including PCAP and DMA)
#include "xdevcfg.h"

/* Requirements:
   - It requires the inclusion of "xilffs_v3_3" in the BSP manually!
   - *NOTE: in ffconf.h we need to do: #define	_USE_STRFUNC 1 (it was 0 originally)
   - In 'Generate Linker Script', change the heap/stack size to allow for input, intermediate data.
     Also, place the code, and heap/stack in the largest memory (DDR).
     This project has been tested to work with: Heap: 3.89 MB  Stack: 51.75 KB. Bitstream size: 1194704 bytes
*/
FATFS FatFs; // work area (file system object) for logical drive

#define SLCR_LOCK	0xF8000004 /**< SLCR Write Protection Lock */
#define SLCR_UNLOCK	0xF8000008 /**< SLCR Write Protection Unlock */
#define SLCR_LVL_SHFTR_EN 0xF8000900 /**< SLCR Level Shifters Enable */
#define SLCR_PCAP_CLK_CTRL XPAR_PS7_SLCR_0_S_AXI_BASEADDR + 0x168 /**< SLCR
					* PCAP clock control register address
					*/

#define SLCR_PCAP_CLK_CTRL_EN_MASK 0x1
#define SLCR_LOCK_VAL	0x767B
#define SLCR_UNLOCK_VAL	0xDF0D

#define INTC_DEVICE_ID			XPAR_SCUGIC_SINGLE_DEVICE_ID

int load_bit_to_pcap (XDcfg *DevcfgInstPtr , u8 *dataPtr, UINT BitstreamLength, u8 flags);
void cordic16p_test (u32 baseaddr, u32 format);


/* Procedure (tested successfully (got same data as in simulation for 4 sets for each of the 4 formats)
 * - Start with [16 15] as a full bitstream (program with this bitstream in Vivado)
 * - Test with [16 15]
 * -  Perform DPR to [16 14]
 * - Test with [16 14].
 * -  Perform DPR to [16 13]
 * - Test with [16 13].
 * -  Perform DPR to [16 12]
 * - Test with [16 12].
 */

int main()
{
    u32 Status;
	u8 *in_bit16_12, *in_bit16_13, *in_bit16_14, *in_bit16_15;
	u32 BitstreamSizea, BitstreamSizeb, BitstreamSizec, BitstreamSized;
    u32 baseaddr = XPAR_MYCORDICFULL_0_S00_AXI_BASEADDR; //  baseaddr = 0x7AA00000; // fixed in Vivado 2016.2!
    FRESULT mystat;

    xil_printf ("\nInterrupt + DPR Test:\n************************\n");

    in_bit16_12 = (u8 *) calloc (65000,sizeof(u8));
    if (in_bit16_12 == NULL) {xil_printf("(main): not enough memory\r\n"); return -1;}

    in_bit16_13 = (u8 *) calloc (65000,sizeof(u8));
    if (in_bit16_13 == NULL) {xil_printf("(main): not enough memory\r\n"); return -1;}

    in_bit16_14 = (u8 *) calloc (65000,sizeof(u8));
    if (in_bit16_14 == NULL) {xil_printf("(main): not enough memory\r\n"); return -1;}

    in_bit16_15 = (u8 *) calloc (65000,sizeof(u8));
    if (in_bit16_15 == NULL) {xil_printf("(main): not enough memory\r\n"); return -1;}


    // Stream partial bitstream to PCAP: Transfer Bitfile using DEVCFG/PCAP
    	XDcfg Instdevcfg;

    // Mounting SD Drive
	   mystat = f_mount(&FatFs, "0:/", 1); // register work area to the default drive ("0:/")
	   if (mystat != FR_OK) { xil_printf("f_mount: Error!\n"); return XST_FAILURE; };

    // Read partial bitstream files from SD and place them in memory
    Status = load_sd_to_memory ("cd16_12.bin", in_bit16_12, &BitstreamSizea, 1);
    if (Status != XST_SUCCESS) { xil_printf ("(main) Error loading file from SD to memory!\n"); return -1; }

    Status = load_sd_to_memory ("cd16_13.bin", in_bit16_13, &BitstreamSizeb, 1);
    if (Status != XST_SUCCESS) { xil_printf ("(main) Error loading file from SD to memory!\n"); return -1; }

    Status = load_sd_to_memory ("cd16_14.bin", in_bit16_14, &BitstreamSizec, 1);
    if (Status != XST_SUCCESS) { xil_printf ("(main) Error loading file from SD to memory!\n"); return -1; }

    Status = load_sd_to_memory ("cd16_15.bin", in_bit16_15, &BitstreamSized, 1);
    if (Status != XST_SUCCESS) { xil_printf ("(main) Error loading file from SD to memory!\n"); return -1; }

    // **** TESTING ///

    // Initial Configuration: [16 15]. Testing data: 4 operations
      xil_printf ("Testing: Format [16 15]\n");
      cordic16p_test(baseaddr, 15);
      // Reconfigure:
	    xil_printf ("Performing DPR. Convert to [16 14]\n");
        Xil_DCacheFlush(); // either disable or flush! (VERY IMPORTANT)
        Status = load_bit_to_pcap (&Instdevcfg , in_bit16_14, BitstreamSizeb, 0x00); // Assumption: Bitstreamsize is multiple of 4
        if (Status != XST_SUCCESS) { xil_printf("(main) Error performing DPR!"); return -1; }

    // Second Configuration: [16 14]. Testing data: 4 operations
    xil_printf ("Testing: Format [16 14]\n");
    cordic16p_test(baseaddr, 14);
    // Reconfigure:
	   xil_printf ("Performing DPR. Convert to [16 13]\n");
       //Xil_DCacheFlush(); // either disable or flush! (VERY IMPORTANT)
       Status = load_bit_to_pcap (&Instdevcfg , in_bit16_13, BitstreamSizec, 0x00); // Assumption: Bitstreamsize is multiple of 4
       if (Status != XST_SUCCESS) { xil_printf("(main) Error performing DPR!"); return -1; }

    // Third Configuration: [16 13]. Testing data: 4 operations
    xil_printf ("Testing: Format [16 13]\n");
    cordic16p_test(baseaddr, 13);
    // Reconfigure:
	   xil_printf ("Performing DPR. Convert to [16 12]\n");
       //Xil_DCacheFlush(); // either disable or flush! (VERY IMPORTANT)
       Status = load_bit_to_pcap (&Instdevcfg , in_bit16_12, BitstreamSized, 0x00); // Assumption: Bitstreamsize is multiple of 4
       if (Status != XST_SUCCESS) { xil_printf("(main) Error performing DPR!"); return -1; }

    // Fourth Configuration: [16 12]. Testing data: 4 operations
    xil_printf ("Testing: Format [16 12]\n");
    cordic16p_test(baseaddr, 12);

    free(in_bit16_12); free(in_bit16_13); free(in_bit16_14); free(in_bit16_15);
    return 0;
}

// ******************* FUNCTION DEFINITIONS ***********************************
void cordic16p_test(u32 baseaddr, u32 format)
{
	// Formats: [16 12], [16 13], [16 14], [16 15]
	//   For every set: input:  1st word: Xin&Yin	2nd word: 0&mode&Zin
	//                  output: 1st word: Xout&Yout 2nd word: 0&Zout
    int i;
	  xil_printf ("Testing 4 CORDIC operations:\n"); // Testing data: 9 32-bit words.
	  if (format == 12)
	  {
		  xil_printf ("Data in Format [16 12]:\n");
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x20002000);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x00000C91);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0xE19AE400);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x0000F79F);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x18002000);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x00010000); // mode = 1
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x1C001C00);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x00010000); // mode = 1
	  }
	  else if (format == 13)
	  {
		  xil_printf ("Data in Format [16 13]:\n");
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x20002000);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x00000C91);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x136F136F);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x00003244);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x1CCD1CCD);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x00010000); // mode = 1
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x1E662000);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x00010000); // mode = 1
	  }
	  else if (format == 14)
	  {
		  xil_printf ("Data in Format [16 14]:\n");
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x000026DD);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x00002182);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x000026DD);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x0000BCFA);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x33333333);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x00010000); // mode = 1
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x20004000);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x00010000); // mode = 1
	  }
	  else if (format == 15)
	  {
		  xil_printf ("Data in Format [16 15]:\n");
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x00004DBA);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x00006488);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x00004DBA);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x0000BCFB);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x40002000);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x00010000); // mode = 1
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x399A2666);
		  MYCORDICFULL_mWriteMemory(baseaddr, 0x00010000); // mode = 1
	  }
	  else
	  {
		  xil_printf ("Error! Formats can only be [16 12], [16 13], [16 14], [16 15]!\n");
	  }

	  if  ( (format == 12) | (format == 13) | (format == 14) | (format == 15) )
		{
		  for (i=0; i < 8; i++)
			xil_printf ("\tReceived data: 0x%08x\n", MYCORDICFULL_mReadMemory(baseaddr));
		}
}

int load_bit_to_pcap (XDcfg *DevcfgInstPtr, u8 *dataPtr, UINT BitstreamLength, u8 flags)
// We load partial bitstreams (.bin format) to PCAP:
//    Usually, we would use a function to read the header of a .bit file and extract size. Now (7 Series), apparently we can't. We have to use .bin files
//    we could try to parse the header (manually, we discovered in one example the header to be 125 bytes) and get the bitstream size, but Xilinx does not provide
//    any help on this
// this only does PArtial REconfiguration. For full reconf,. details, see devcfg_polled_example.c
// ASSUMPTION: Bitstreamlength is multiple of 4
// BitstreamLength: Size of bitstream (bytes): It has to be a multiple of 4
// flags: various options:
//  flags = 0x?E: We print registers at the end
//  flags = 0xA?: Order of bytes is swapped (this is when the .bin was generated by write_bitstream)

// This can be very useful. For example: flags=0xAE: swap byte order and print registers at the end.
{
	u32 IntrStsReg = 0;
    XDcfg_Config *ConfigPtr;
    int Status;
    int i;
    u8 ta, tb, tc, td;

    // In a .bit file, the header is included. If the header is 125 bytes, we can do this:
      // in_dat = in_dat + 0x0000007D; // used to skip the header in a .bit file.
      // BitstreamLength = BitstreamLenght-125;
    // Also note that for a .bit file, we need to swap the byte order.

    if ( (flags & 0xF0) == 0xA0) {
       // Little-endian: the .bin generated by write_bitstream. We need to swap the byte order in a 32-bit word
       xil_printf ("(load_bit_to_pcap): Swapping bytes in a 32-bit word\n");

       for (i=0; i< BitstreamLength/4; i++)
       {
    	   ta = dataPtr[4*i]; tb = dataPtr[4*i+1]; tc = dataPtr[4*i+2]; td = dataPtr[4*i+3];
    	   dataPtr[4*i] = td; dataPtr[4*i+1] = tc; dataPtr[4*i+2] = tb; dataPtr[4*i+3] = ta;
       }
    }

    // Use XMD%mrd to see data in memory (32-bit words, byte at 0 is the LSByte).
    // To see data byte-wise, use:
    // for ( i = 0; i < BitstreamLength; i++ ) xil_printf("Received data: %d: 0x%02X\n", i,*(in_dat + i) );

	//XDcfg Instpcap;
	u16 DeviceId = XPAR_PS7_DEV_CFG_0_DEVICE_ID;

	// Performing DPR:
	ConfigPtr = XDcfg_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {xil_printf ("(load_bit_to_pcap) XDcfg_LookupConfig failed\n"); return XST_FAILURE;}

	// Using Physical Address to initialize Devcfg
	Status = XDcfg_CfgInitialize(DevcfgInstPtr, ConfigPtr, ConfigPtr->BaseAddr);
	if (Status != XST_SUCCESS) { xil_printf ("(load_bit_to_pcap) XDcfg_CfgInitiliaze failed!\n"); return XST_FAILURE; }
	XDcfg_SetLockRegister(DevcfgInstPtr, XDCFG_UNLOCK_DATA); //0x757BDF0D);

	// Check 1st time configuration or not. If it is not, this is likely a Partial Reconfiguration.
	//  But even if it is the 1st, we can also do Partial Reconfiguration
	IntrStsReg = XDcfg_IntrGetStatus(DevcfgInstPtr); xil_printf ("(load_bit_to_pcap) IntrStsReg: %08X: \n",IntrStsReg);
	if (IntrStsReg & XDCFG_IXR_DMA_DONE_MASK) xil_printf("PartialCfg = 1 (i.e., not 1st configuration)!\n");
	   // First time Configuration: understood as if the entire chip is programmed. we are not doing this here!.

	// enable PCAP clock:
	Status = Xil_In32(SLCR_PCAP_CLK_CTRL);
	if (!(Status & SLCR_PCAP_CLK_CTRL_EN_MASK)) {
			Xil_Out32(SLCR_UNLOCK, SLCR_UNLOCK_VAL);
			Xil_Out32(SLCR_PCAP_CLK_CTRL, (Status | SLCR_PCAP_CLK_CTRL_EN_MASK));
			Xil_Out32(SLCR_UNLOCK, SLCR_LOCK_VAL);
	}

	// Enable PCAP interface for Partial Reconfiguration: Configure muxes so that the PCAP Path is enabled to write on PL Conf. Module
	XDcfg_SetControlRegister(DevcfgInstPtr, XDCFG_CTRL_PCAP_MODE_MASK); // Setting control register for PCAP mode --> this is also done by XDcfg_EnablePCAP(DevcfgInstPtr)
	XDcfg_SetControlRegister(DevcfgInstPtr, XDCFG_CTRL_PCAP_PR_MASK);  // Setting PR mode
     // We should probably go back to the orig. state when done)

	// Clear Interrupt Status Bits: DMA and PCAP Done Interrupts
	XDcfg_IntrClear(DevcfgInstPtr, (XDCFG_IXR_PCFG_DONE_MASK | XDCFG_IXR_DMA_DONE_MASK | XDCFG_IXR_D_P_DONE_MASK));

    xil_printf ("(load_bit_to_pcap) Interrupt Status bits cleared! IntrStsReg: %08X\n", XDcfg_IntrGetStatus(DevcfgInstPtr));

    // Check if DMA command queue is full:
	Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_STATUS_OFFSET); // sometimes they use Inspcap->Config.BaseAddr
	if ((Status & XDCFG_STATUS_DMA_CMD_Q_F_MASK) == XDCFG_STATUS_DMA_CMD_Q_F_MASK) {
	    xil_printf("DMA command queue is full.\n\r"); return XST_FAILURE; }

	xil_printf ("(load_bit_to_pcap) DPR: Transfer to start: Source Address: %08X...\n", dataPtr);

	// Download bitstream to PL in nonsecure more:
	Status = XDcfg_Transfer(DevcfgInstPtr, dataPtr, BitstreamLength/4, (u8 *) XDCFG_DMA_INVALID_ADDRESS, 0, XDCFG_NON_SECURE_PCAP_WRITE);
	if (Status != XST_SUCCESS) { xil_printf ("XDcfg_Transfer: failure: %d\n",Status); return XST_FAILURE; }

	xil_printf ("(load_bit_to_pcap) DPR: Transfer completed!\n");

	IntrStsReg = XDcfg_IntrGetStatus(DevcfgInstPtr);
	// Poll DMA Done Interrupt
	while ((IntrStsReg & XDCFG_IXR_DMA_DONE_MASK) != XDCFG_IXR_DMA_DONE_MASK) IntrStsReg = XDcfg_IntrGetStatus(DevcfgInstPtr);

	// Poll PCAP Done Interrupt
	while ((IntrStsReg & XDCFG_IXR_D_P_DONE_MASK) != XDCFG_IXR_D_P_DONE_MASK) IntrStsReg = XDcfg_IntrGetStatus(DevcfgInstPtr);

	if ( (flags & 0x0F) == 0x0E ) {
		xil_printf ("\nINS_STS: Interrupt Status Register: %08X: \n",IntrStsReg);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_STATUS_OFFSET);
		xil_printf ("STATUS Register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_CTRL_OFFSET);
		xil_printf ("CONTROL register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_CFG_OFFSET);
		xil_printf ("CONFIGURATION Register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_DMA_SRC_ADDR_OFFSET);
		xil_printf ("SRC ADDRESS register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_DMA_DEST_ADDR_OFFSET);
		xil_printf ("DEST ADDRESS register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_DMA_SRC_LEN_OFFSET);
		xil_printf ("SRC LENGTH register: %08X: \n",Status);

		Status = XDcfg_ReadReg(ConfigPtr->BaseAddr, XDCFG_DMA_DEST_LEN_OFFSET);
		xil_printf ("DEST LENGTH register: %08X: \n",Status);
	}
	return XST_SUCCESS;
	}

