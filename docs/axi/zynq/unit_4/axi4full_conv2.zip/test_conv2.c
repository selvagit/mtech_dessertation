
#include <stdio.h>
#include "myconv2full.h"
#include "xparameters.h"
#include "stdio.h"
#include "xil_io.h"

int main()
{
	u32 baseaddr, Mem32Value;

	// Enabling caches
    Xil_DCacheEnable();
    Xil_ICacheEnable();

    xil_printf("AXI4-Full Pipelined 2D Convolution Peripheral: Test\n\r");
    baseaddr = XPAR_MYCONV2FULL_0_S00_AXI_BASEADDR;
    //baseaddr = 0x7AA00000; // Due to a bug, in some cases the XPAR_MYPIXFULL_0_S00_AXI_BASEADDR is incorrect.

    xil_printf("Peripheral: Base address is 0x%08x\n\r", baseaddr);

    xil_printf ("Set 1:\n");
    // The offset does not matter as the AXI4-Full peripheral is built to accept any address in the 64 byte range.
	MYCONV2FULL_mWriteMemory(baseaddr, (0xA1B2C3D4));
	MYCONV2FULL_mWriteMemory(baseaddr, (0xF0E1D2C3));
	MYCONV2FULL_mWriteMemory(baseaddr, (0x000000B3));

	// Reading data: Again, here using baseaddr+4*Index or 'baseaddr' does not matter.
	Mem32Value = MYCONV2FULL_mReadMemory(baseaddr);
	xil_printf("Pipelined 2D Convolver - Result: %08x\n", Mem32Value);

    xil_printf ("Set 2:\n"); // note that you can write Set 1 and Set 1  first, and then retrieve the results.
    // The offset does not matter as the AXI4-Full peripheral is built to accept any address in the 64 byte range.
	MYCONV2FULL_mWriteMemory(baseaddr, (0xF109050A));
	MYCONV2FULL_mWriteMemory(baseaddr, (0xC302A1F0));
	MYCONV2FULL_mWriteMemory(baseaddr, (0x0000001C));

	// Reading data: Again, here using baseaddr+4*Index or 'baseaddr' does not matter.
	Mem32Value = MYCONV2FULL_mReadMemory(baseaddr);
	xil_printf("Pipelined 2D Convolver - Result: %08x\n", Mem32Value);

    //  Result 1st Set: 00102B82
    //  Result 2nd SEt: 001018FF
    // It matches the AXI Full Simulation

    Xil_DCacheDisable();
    Xil_ICacheDisable();

    return 0;
}
