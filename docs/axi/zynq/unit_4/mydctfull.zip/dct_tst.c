#include <stdio.h>
#include "mydctfull.h"
#include "xparameters.h"
#include "stdio.h"
#include "xil_io.h"

int main()
{
	u32 baseaddr, Mem32Value;
	int Index;

	// Enabling caches
	Xil_DCacheEnable();	Xil_ICacheEnable();

    xil_printf("DCT 2D AXI4-Full Peripheral - 4x4 - Test\n\r");
    baseaddr = XPAR_MYDCTFULL_0_S00_AXI_BASEADDR; // from xparameters.h.
    // Sometimes, due to a bug, we do not have the correct XPAR_MYDCTFULL_0_S00_AXI_BASEADDR
    // You have to look into Vivado for the peripheral address: baseaddr = 0x7AA00000;

    xil_printf("Base memory address is 0x%08x\n", baseaddr);

    // The way the AXI4-Full Peripheral was built so that writes/read occur in any of the 64-byte memory range.
    xil_printf ("First block\n\r");
    MYDCTFULL_mWriteMemory(baseaddr, (0xDEADBEEF)); // same thing, the index does not make a difference, it seems
    MYDCTFULL_mWriteMemory(baseaddr, (0xBEBEDEAD));
    MYDCTFULL_mWriteMemory(baseaddr, (0xFADEBEAD));
    MYDCTFULL_mWriteMemory(baseaddr, (0xCAFEBEDF));

	xil_printf(" Data written !!\n\r");
	for ( Index = 0; Index < 8; Index++ ) {
	  Mem32Value = MYDCTFULL_mReadMemory(baseaddr); // we get the same results here (as expected, by reading anything on the 64-bytes we read the same)
	  xil_printf("Received data is 0x%08x\n", Mem32Value);
	}

	xil_printf ("Second block\n\r");
	MYDCTFULL_mWriteMemory(baseaddr, (0xCFC7C9C7)); // same thing, the index does not make a difference, it seems
	MYDCTFULL_mWriteMemory(baseaddr, (0xCAC4C6C3));
	MYDCTFULL_mWriteMemory(baseaddr, (0xC6C3C7C3));
	MYDCTFULL_mWriteMemory(baseaddr, (0xBEBDC2BD));

	xil_printf(" Data written !!\n\r");
	for ( Index = 0; Index < 8; Index++ )
	{
	  Mem32Value = MYDCTFULL_mReadMemory(baseaddr); // we get the same results here (as expected, by reading anything on the 64-bytes we read the same)
	  xil_printf("Received data is 0x%08x\n", Mem32Value);
	}

    // Disabling caches
	Xil_DCacheDisable(); Xil_ICacheDisable();

    return 0;
}
