
#include <stdio.h>
#include "mypixfull.h"
#include "xparameters.h"
#include "stdio.h"
#include "xil_io.h"

int main()
{
	u32 baseaddr, Mem32Value;
	int i;

	// Enabling caches
    Xil_DCacheEnable();
    Xil_ICacheEnable();

    xil_printf("Pixel Processor AXI4-Full Peripheral: Test\n\r");
    baseaddr = XPAR_MYPIXFULL_0_S00_AXI_BASEADDR;
    //baseaddr = 0x7AA00000; // Due to a bug, in some cases the XPAR_MYPIXFULL_0_S00_AXI_BASEADDR is incorrect.

	/*
	 * Write data to user logic BRAMs and read back: A simple for-loop might take care of the bursts,
	 * though it has be used in conjunction with a cache to make sure the bursts happen
	 * The previous one might not be a solution (some claim that it is with burst length of 8, requires painful verification)
	 */

    xil_printf("Peripheral: Base address is 0x%08x\n\r", baseaddr);

/*  for ( Index = 0; Index < 16; Index++ )
    	MYPIXFULL_mWriteMemory(baseaddr+4*Index, (0xDEADBEEF + Index));
	for ( Index = 0; Index < 16; Index++ ) {
	  Mem32Value = MYPIXFULL_mReadMemory(baseaddr+4*Index);
	  xil_printf("Received data is 0x%08x\n\r", Mem32Value);}
*/

    // The offset does not matter as our AXI4-Full peripheral is built to accept any address in the 64 byte range.
 	   MYPIXFULL_mWriteMemory(baseaddr, (0xF00DBEEF));
	   MYPIXFULL_mWriteMemory(baseaddr, (0xBEBEDEAF));
	   MYPIXFULL_mWriteMemory(baseaddr, (0xFADEDEAD));
	   MYPIXFULL_mWriteMemory(baseaddr, (0xCAFEC0C0));

	// Reading data: Again, here using baseaddr+4*Index or 'baseaddr' does not matter.
	   // we could've read from any address and it would've worked fine
		for (i = 0; i < 4; i++ )
		{
		  Mem32Value = MYPIXFULL_mReadMemory(baseaddr + 4*i);
		  xil_printf("Received data is 0x%08x\n", Mem32Value);
		}

    Xil_DCacheDisable();
    Xil_ICacheDisable();

    return 0;
}
