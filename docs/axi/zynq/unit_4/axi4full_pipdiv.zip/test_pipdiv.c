
#include <stdio.h>
#include "mypipdivfull.h"
#include "xparameters.h"
#include "stdio.h"
#include "xil_io.h"

int main()
{
	u32 baseaddr, Mem32Value;
	int i;

	// Enabling caches
    Xil_DCacheEnable();
    Xil_ICacheEnable();

    xil_printf("AXI4-Full Pipelined Divider Peripheral: Test\n\r");
    baseaddr = XPAR_MYPIPDIVFULL_0_S00_AXI_BASEADDR;
    //baseaddr = 0x7AA00000; // Due to a bug, in some cases the XPAR_MYPIXFULL_0_S00_AXI_BASEADDR is incorrect.

	/*
	 * Write data to user logic BRAMs and read back: A simple for-loop might take care of the bursts,
	 * though it has be used in conjunction with a cache to make sure the bursts happen
	 * The previous one might not be a solution (some claim that it is with burst length of 8, requires painful verification)
	 */

    xil_printf("Peripheral: Base address is 0x%08x\n\r", baseaddr);

    // The offset does not matter as the AXI4-Full peripheral is built to accept any address in the 64 byte range.
	MYPIPDIVFULL_mWriteMemory(baseaddr + 2*4, (0x008C0009)); // Q = 0x0F, R = 0x05
	MYPIPDIVFULL_mWriteMemory(baseaddr + 1*4, (0x00BB000A)); // Q = 0x12, R = 0x07
	MYPIPDIVFULL_mWriteMemory(baseaddr + 4*4, (0x0FEA0371)); // Q = 0x04, R = 0x226
	MYPIPDIVFULL_mWriteMemory(baseaddr + 3*4, (0x09640037)); // Q = 0x2B, R = 0x27

	// Reading data: Again, here using baseaddr+4*Index or 'baseaddr' does not matter.
	   for (i = 0; i < 4; i++ )
		{
		  Mem32Value = MYPIPDIVFULL_mReadMemory(baseaddr+4*i);
		  xil_printf("Data Received (Q|R) is 0x%08x\n", Mem32Value);
		}

    Xil_DCacheDisable();
    Xil_ICacheDisable();

    return 0;
}
