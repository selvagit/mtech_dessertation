/* 	pix_proc_test.c
 * 	###############################################################################
 *
 * 	A simple software application to test the functionality of the led_controller
 * 	IP core. The value of a counter is output to the LEDs.
 *
 * 	###############################################################################
 * 	v1.0 -- 25/10/2013
 * 	############################################################################### */

/* Generated driver function for led_controller IP core */
#include <stdio.h>
#include "mypix.h"
#include "xparameters.h"
#include <xil_io.h>

// Define maximum LED value (2^8)-1 = 255
#define PIX_PROC_LIMIT 256
// Define delay length
#define DELAY 1000000

/* 	Define the base memory address of the led_controller IP core */
#define MYPIX_BASE XPAR_MYPIX_0_S00_AXI_BASEADDR
//#define MYPIX_BASE 0x43C00000 // sometimes the xparameters.h is wrongly created with the wrong
                              // low address for MYPIX peripheral
                              // always look at the Address Editor for the correct address
/* main function */
int main(void){
	/* unsigned 32-bit variables for storing current LED value */
	u32 i, value, ival;

	xil_printf("Pixel Processor IP test begin\r\n");
	xil_printf("--------------------------------------------\r\n");

	for (i = 0; i < PIX_PROC_LIMIT; i++)
	{		/* Print value to terminal */
		ival = i*(256*256*256) + i*(256*256) + i*256 + i; // 32-bit input: |8|8|8|8|
		xil_printf("Input value: %08X\t", ival);

		/* Write value to led_controller IP core using generated driver function */
		MYPIX_mWriteReg(MYPIX_BASE, 0, ival);

		//for(i=0;i<DELAY;i++); // here you can force a waiting period
		// Reading data back
		value = MYPIX_mReadReg(MYPIX_BASE, 4); // 4 because this is slave reg 1 (4 bytes after)
		xil_printf("Output value: %08X\n", value);
		//for(i=0;i<DELAY;i++);
	}
	return 1;
}
