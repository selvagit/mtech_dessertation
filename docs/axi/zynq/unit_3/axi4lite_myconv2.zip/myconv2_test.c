/* Generated driver function for led_controller IP core */
#include "myconv2.h"
#include "xparameters.h"
#include <xil_io.h>
#include "xtime_l.h"

/* 	Define the base memory address of the led_controller IP core */
//#define MYPIX_BASE XPAR_MYPIX_0_S00_AXI_BASEADDR
#define MY_HW_BASE XPAR_MYCONV2_0_S00_AXI_BASEADDR //0x43C00000 // sometimes the xparameters.h is wrongly created with the wrong
                              // always look at the Address Editor for the correct address

/* main function */
int main(void){
	/* unsigned 32-bit variables for storing current LED value */
	u32 value;
	XTime TimeStart=0, TimeEnd=0; // 64-bit values

	xil_printf("CONV2 - Hardware Test\r\n");
	xil_printf ("Timer (Counts per second): %d\r\n", COUNTS_PER_SECOND);
	xil_printf("--------------------------------------------\r\n");

	   // For the settings: output data is 21-bits wide (MSB is 'v'). Input data is 8-bits wide for each of the 9 pixels
	   // pooltype = 00 (max)
	   // Also, HW is working at 50 MHz

	   XTime_GetTime (&TimeStart);
	   Xil_Out32(MY_HW_BASE + 0*4, 0xA1B2C3D4); // MYCONV2_mWriteReg (MY_HW_BASE, 0, 0xA1B2C304)
	   Xil_Out32(MY_HW_BASE + 1*4, 0xF0E1D2C3); // MYCONV2_mWriteReg (MY_HW_BASE, 4, 0xF0E1D2C3)
	   Xil_Out32(MY_HW_BASE + 2*4, 0x000000B3); // MYCONV2_mWriteReg (MY_HW_BASE, 8, 0x000000B3)

	   // Here, you might poll slv_reg2(20)=v to detect whether data is ready
	   // But the time elapsed between instructions is enough in this particular case.
	   //  If you want to double check, read slv_reg2(20).

       value = Xil_In32(MY_HW_BASE + 3*4); // value = MYCONV2_mReadReg (MY_HW_BASE, 12)
       XTime_GetTime (&TimeEnd);

       u32 x_l, x_h;
       x_l = TimeStart & ~0x0;
       x_h = (TimeStart >> 32);

       xil_printf ("1st Set - CONV2 Result: %08X\r\n", value);

       xil_printf ("\tTime Start (hex) = %08X %08X\r\n", x_h, x_l);
       // for some reason, %016X does not work...
       printf ("\tTime Start: %lld\r\n", TimeStart);
       printf ("\tTime End: %lld\r\n", TimeEnd);
       printf ("\tElapsed time: %lld\r\n", TimeEnd-TimeStart);

       printf ("\tElapsed time: %4.4f us\r\n", (1000000*((float)TimeEnd-(float)TimeStart)/ (float) COUNTS_PER_SECOND));
       // this one seems to work better.


       // **********************************************************


	   // Here, you might poll slv_reg2(20)=v to detect whether data is ready
	   // But we will read immediately since time between instructions is enough in this particular case.

	   Xil_Out32(MY_HW_BASE + 0*4, 0xF109050A);
	   Xil_Out32(MY_HW_BASE + 1*4, 0xC302A1F0);
	   Xil_Out32(MY_HW_BASE + 2*4, 0x0000001C);

	   // Here, you might poll slv_reg2(0)=v to detect whether data is ready
	   // But we will read immediately since time between instructions is enough in this particular case.
       //value = MY_HW_mReadReg (MY_HW_BASE,3*4); // Reading from Register 3

       value = Xil_In32(MY_HW_BASE + 3*4);

       xil_printf ("2nd Test - CONV2 Result: %08X\r\n", value);

     //  Result: 00102B82
     //  Result: 001018FF
     // It matches the AXI Lite Simulation

	return 1;
}
