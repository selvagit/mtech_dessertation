/* Generated driver function for led_controller IP core */
#include <stdio.h>
#include "mydiv.h"
#include "xparameters.h"
#include <xil_io.h>
// Define delay length
#define DELAY 1000000

/* 	Define the base memory address of the led_controller IP core */
//#define MYPIX_BASE XPAR_MYPIX_0_S00_AXI_BASEADDR
#define MYDIV_BASE 0x43C00000 // sometimes the xparameters.h is wrongly created with the wrong
                              // low address for MYPIX peripheral
                              // always look at the Address Editor for the correct address

/* main function */
int main(void){
	/* unsigned 32-bit variables for storing current LED value */

	u32 value, Q,R;

	xil_printf("Pipelined Divider IP test\r\n");
	xil_printf("--------------------------------------------\r\n");

	// Slave Register 0: Base Address + 0*4:    |A|B|
	// Slave Register 1: Base Address + 1*4:    |Q|R|
	// Slave Register 2: Base Address + 2*4: |0..0&v|

	// SET 1
	// *******
	// writing input data: A = 0x008C, B = 0x0009, expected: Q = 0x000F, R = 0x0005
	   xil_printf ("Set 1: A = 008C, B = 0009\t =>\t");
	   MYDIV_mWriteReg (MYDIV_BASE, 0, 0x008C0009); // Writing on Register 0

	   // Here, we poll slv_reg2(0)=v to detect whether data is ready
	   // Time elapsed between write and read might not be enough in this case.
	   // Note: you can also insert a small software delay between write and read to avoid polling for 'v'
	   //   The processing cycles is not large (~16 cycles). But not very small either
	   //   * Actually, the time overhead of this do-while loop might be longer than the processing cycles of the divider
	   do { // this avoids having to clear 'value' for every new set (as opposed to a while loop)
		   value = MYDIV_mReadReg (MYDIV_BASE, 2*4); // Reading from Register 2
	   } while ( value != 0x00000001 );

	   // But we will read immediately since time between write and read (including the xil_printf) is enough in this particular example.
	   // * If you do not get the right response, double-check for v = 1 (by reading Register 2)
       value = MYDIV_mReadReg (MYDIV_BASE,4); // Reading from Register 1

       Q = (value&0xFFFF0000)/0x10000;   R = value&0x0000FFFF;
       xil_printf ("Q = %04X, R = %04X\r\n", Q, R);

    // SET 2
    // *******
   	// writing input data: A = 0x00BB, B = 0x000A, expected: Q = 0x0012, R = 0x0007
   	   xil_printf ("Set 2: A = 00BB, B = 000A\t =>\t");
   	   MYDIV_mWriteReg (MYDIV_BASE, 0, 0x00BB000A); // Writing on Register 0

	   // Here, we poll slv_reg2(0)=v to detect whether data is ready
	   // Time elapsed between write and read might not be enough in this case.
	   do { // this avoids having to clear 'value' for every new set (as opposed to a while loop)
		   value = MYDIV_mReadReg (MYDIV_BASE, 2*4); // Reading from Register 2
	   } while ( value != 0x00000001 );

   	   value = MYDIV_mReadReg (MYDIV_BASE,4); // Reading from Register 1

       Q = (value&0xFFFF0000)/0x10000;  R = value&0x0000FFFF;
       xil_printf ("Q = %04X, R = %04X\r\n", Q, R);

    // SET 3
    // ******
    // writing input data: A = 0x0FEA, B = 0x0371, expected: Q = 0x0004, R = 0x0226
       xil_printf ("Set 3: A = 0FEA, B = 0371\t =>\t");
       MYDIV_mWriteReg (MYDIV_BASE, 0, 0x0FEA0371); // Writing on Register 0

       // Here, we poll slv_reg2(0)=v to detect whether data is ready
	   // Time elapsed between write and read might not be enough in this case.
	   do { // this avoids having to clear 'value' for every new set (as opposed to a while loop)
		   value = MYDIV_mReadReg (MYDIV_BASE, 2*4); // Reading from Register 2
	   } while ( value != 0x00000001 );

	   value = MYDIV_mReadReg (MYDIV_BASE,4); // Reading from Register 1

       Q = (value&0xFFFF0000)/0x10000;  R = value&0x0000FFFF;
       xil_printf ("Q = %04X, R = %04X\n", Q, R);

	return 1;
}
