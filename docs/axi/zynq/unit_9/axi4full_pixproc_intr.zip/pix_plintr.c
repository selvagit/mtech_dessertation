/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* XILINX CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/
#include <stdio.h>
#include "mypixfullintr.h"
#include "xparameters.h"
#include "stdio.h"
#include "xil_io.h"
#include "xscugic.h"

#define INTC_DEVICE_ID			XPAR_SCUGIC_SINGLE_DEVICE_ID

int SetupInterruptSystem(XScuGic *GicPtr);
void DeviceDriverHandler(void *CallbackRef);


volatile static int InterruptProcessed = FALSE;

XScuGic GicInstance;


int main()
{
	int Index, Status;

	u32 baseaddr = XPAR_MYPIXFULLINTR_0_S00_AXI_BASEADDR; // from xparameters.h

    xil_printf ("Interrupt Test with AXI4-Full Pixel Processor Peripheral\n*************************\n");

    MYPIXFULLINTR_mWriteMemory(baseaddr, 0xDEADBEEF);
    MYPIXFULLINTR_mWriteMemory(baseaddr, 0xDEAFBEAD);
    MYPIXFULLINTR_mWriteMemory(baseaddr, 0xFADEDEAD);
    MYPIXFULLINTR_mWriteMemory(baseaddr, 0xFACEB00C);
	xil_printf ("Received data: 0x%08x\n", MYPIXFULLINTR_mReadMemory(baseaddr));
	xil_printf ("Received data: 0x%08x\n", MYPIXFULLINTR_mReadMemory(baseaddr));
	xil_printf ("Received data: 0x%08x\n", MYPIXFULLINTR_mReadMemory(baseaddr));
	xil_printf ("Received data: 0x%08x\n", MYPIXFULLINTR_mReadMemory(baseaddr));

	// Setup the Interrupt System: GIC (General Interrupt Controller)
	// ***************************************************************
	   Status = SetupInterruptSystem(&GicInstance);
	   if (Status != XST_SUCCESS) { xil_printf ("Setup Interrupt System failed!\n"); return XST_FAILURE; }

	   xil_printf ("Forcing the assertion of PL interrupt: Writing 0x99AA55EE on address 1101 ...\n");
	   MYPIXFULLINTR_mWriteMemory(baseaddr + 13*4, 0x99AA55EE); // Address 110100

	// Waiting for PL Interrupt to be detected by the PS
	   while(1) {
		   if (InterruptProcessed==TRUE) // return value from the ISR

		   {  InterruptProcessed = FALSE;
		      xil_printf ("IRQ from PL detected!\n"); break;}
	   }

	// Testing 4 words again to see whether the interrupt affected the operation of the circuit.
    MYPIXFULLINTR_mWriteMemory(baseaddr, 0xDEADBEEF);
    MYPIXFULLINTR_mWriteMemory(baseaddr, 0xDEAFBEAD);
    MYPIXFULLINTR_mWriteMemory(baseaddr, 0xFADEDEAD);
    MYPIXFULLINTR_mWriteMemory(baseaddr, 0xFACEB00C);
	xil_printf ("Received data: 0x%08x\n", MYPIXFULLINTR_mReadMemory(baseaddr));
    xil_printf ("Received data: 0x%08x\n", MYPIXFULLINTR_mReadMemory(baseaddr));
	xil_printf ("Received data: 0x%08x\n", MYPIXFULLINTR_mReadMemory(baseaddr));
	xil_printf ("Received data: 0x%08x\n", MYPIXFULLINTR_mReadMemory(baseaddr));

    return 0;
}


/******************************************************************************/
/**
 *
 * This function connects the interrupt handler of the interrupt controller to
 * the processor.  This function is separate to allow it to be customized for
 * each application. Each processor or RTOS may require unique processing to
 * connect the interrupt handler.
 *
 * @param	GicPtr is the GIC instance pointer.
 * @param	DmaPtr is the DMA instance pointer.
 *
 * @return	None.
 *
 * @note	None.
 *
 ****************************************************************************/
int SetupInterruptSystem(XScuGic *GicPtr)
{
	int Status;
	XScuGic_Config *GicConfig;

	Xil_ExceptionInit();

	/*
	 * Initialize the interrupt controller driver so that it is ready to
	 * use.
	 */
	GicConfig = XScuGic_LookupConfig(INTC_DEVICE_ID);
	if (NULL == GicConfig) {
		return XST_FAILURE;
	}

	Status = XScuGic_CfgInitialize(GicPtr, GicConfig,
				       GicConfig->CpuBaseAddress);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Perform a self-test to ensure that the hardware was built
	 * correctly
	 */
	Status = XScuGic_SelfTest(GicPtr);
	if (Status != XST_SUCCESS) {return XST_FAILURE;}

	//XScuGic_CPUWriteReg(GicPtr, XSCUGIC_EOI_OFFSET, 0x3D); // ?????
	/*
	 * Connect the interrupt controller interrupt handler to the hardware
	 * interrupt handling logic in the processor.
	 */
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_IRQ_INT,
			     (Xil_ExceptionHandler)XScuGic_InterruptHandler,
			     GicPtr);
	//Xil_ExceptionEnable();

	Status = XScuGic_Connect (GicPtr, XPS_FPGA0_INT_ID, (Xil_ExceptionHandler) DeviceDriverHandler, (void *) GicPtr);
	if (Status != XST_SUCCESS) {xil_printf("\nError connecting IRQ from PL");return XST_FAILURE;}

	/*
	 * Enable the interrupts for the device
	 */

	XScuGic_Enable(GicPtr, XPS_FPGA0_INT_ID);

	Xil_ExceptionEnable();
	return XST_SUCCESS;
}


void DeviceDriverHandler(void *CallbackRef)
{
	/*
	 * Indicate the interrupt has been processed using a shared variable
	 */
	int a;
	InterruptProcessed = TRUE;
	xil_printf("(ISR) PL Interrupt occurred!\n");
	// we can also configure stuff here so that only rising edge works
	// So, it is here that we must de-assert the interrupt source.
	a = MYPIXFULLINTR_mReadMemory(XPAR_MYPIXFULLINTR_0_S00_AXI_BASEADDR + 13*4); // to de-assert interrupt source
    xil_printf ("(DeviceDriverHandler): Word Read: %08X\n",a);
}
